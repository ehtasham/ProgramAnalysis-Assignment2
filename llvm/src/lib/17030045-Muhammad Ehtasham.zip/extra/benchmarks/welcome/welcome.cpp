#include <stdio.h>
int main() {
    printf("Welcome heelo to CSE231!\n");
        printf("Welcome heelo to CSE231!\n");

    printf("Welcome heelo to CSE231!\n");

    printf("Welcome heelo to CSE231!\n");

    return 0;    
}

