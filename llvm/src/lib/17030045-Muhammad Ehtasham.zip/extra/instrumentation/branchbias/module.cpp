#include <stdio.h>
#include <string>
#include <map>


using namespace std;


void count(char * Funcname, int condition)
{	
	
}

void print()
{
	
}
